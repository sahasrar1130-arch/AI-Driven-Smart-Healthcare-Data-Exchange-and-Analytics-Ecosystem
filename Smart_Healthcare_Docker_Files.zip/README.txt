Smart Healthcare — Docker Files

Contents:
- docker-compose.yml: PostgreSQL + pgvector, MongoDB, Redis, Zookeeper and Kafka.
- database/init.sql: enables the pgvector extension.

Run from this folder:
  docker compose up -d
  docker compose ps

Notes:
- These are the Docker/Compose infrastructure files, not the complete application source code.
- Local development credentials in this compose file are for the academic demo only; do not use them in production.
- Existing PostgreSQL volumes are preserved unless you explicitly remove them.
- Backend and frontend are started separately using the project's instructions.
