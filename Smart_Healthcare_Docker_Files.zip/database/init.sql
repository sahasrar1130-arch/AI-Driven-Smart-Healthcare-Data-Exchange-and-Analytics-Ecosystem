CREATE EXTENSION IF NOT EXISTS vector;

-- The FastAPI application's SQLAlchemy models create application tables.
-- This init file enables pgvector for medical-record embeddings.
